import React, { useState } from 'react';
import Header from './components/Header';
import ReviewForm from './components/ReviewForm';
import ReviewResult from './components/ReviewResult';
import { getBossReview, ReviewRequest } from './services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, ShieldCheck, Zap } from 'lucide-react';

export default function App() {
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleReviewRequest = async (request: ReviewRequest) => {
    setIsLoading(true);
    setError(null);
    try {
      const bossReview = await getBossReview(request);
      setResult(bossReview);
    } catch (err) {
      setError(err instanceof Error ? err.message : '알 수 없는 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen pb-20">
      <Header />
      
      <main className="px-6 relative z-10">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <ReviewForm onSubmit={handleReviewRequest} isLoading={isLoading} />
              
              {/* BOSS Policy Quick Links */}
              <div className="max-w-2xl mx-auto mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
                <PolicyCard 
                  icon={BookOpen} 
                  title="BOSS Policy" 
                  desc="기술 리뷰의 기본 원칙과 지향점"
                />
                <PolicyCard 
                  icon={ShieldCheck} 
                  title="Best Samples" 
                  desc="논리가 탄탄했던 과거 보고 장표"
                />
                <PolicyCard 
                  icon={Zap} 
                  title="Review Tips" 
                  desc="위원님들이 자주 주시는 코멘트"
                />
              </div>
            </motion.div>
          ) : (
            <ReviewResult key="result" result={result} onReset={handleReset} />
          )}
        </AnimatePresence>

        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto mt-6 bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl text-center text-sm"
          >
            {error}
          </motion.div>
        )}
      </main>

      {/* Background Decorative Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-orange-200/40 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-teal-100/40 rounded-full blur-[100px]" />
      </div>
    </div>
  );
}

function PolicyCard({ icon: Icon, title, desc }: { icon: any, title: string, desc: string }) {
  return (
    <div className="p-6 bg-white/40 backdrop-blur-md rounded-3xl border border-white/50 shadow-sm hover:shadow-md transition-all group">
      <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-glass-accent mb-4 group-hover:scale-110 shadow-sm transition-transform">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="font-bold text-slate-800 mb-2">{title}</h3>
      <p className="text-xs text-slate-500 leading-relaxed">{desc}</p>
    </div>
  );
}


