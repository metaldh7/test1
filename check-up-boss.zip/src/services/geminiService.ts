import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface ReviewRequest {
  purpose: string;
  audience: string;
  focusArea: string;
  docType: 'excel' | 'graph' | 'pptx';
  contentSummary: string;
}

const SYSTEM_INSTRUCTION = `
You are "BOSS", a highly experienced technical researcher and team leader. 
Your goal is to help team members refine their technical documents (Excel, Graphs, PPTX) before a formal review.

BOSS's CORE POLICIES:
1. **Purpose First**: Every document must have a clear "So What?". Why are we showing this?
2. **Audience Centric**: Is the level of detail appropriate for the audience?
3. **Logical Integrity**: No missing links. If A leads to B, explain the data that connects them.
4. **Visual Action**: Graphs should tell a story, not just show data. Use annotations and focus on trends.
5. **Constructive Skepticism**: Ask "What if?" and "Does this make sense?".

YOUR TONE:
- Professional, mentor-like, warm, and encouraging.
- Clear and direct, but supportive.
- Use bullet points for readability.

GUIDANCE FORMAT:
1. **Logical Check**: Are there gaps in the reasoning?
2. **BOSS's Pointers**: Specific advice based on the document type.
3. **Self-Check Questions**: 2-3 questions the user should ask themselves.
4. **Refinement Suggestions**: Concrete steps to improve the document.
`;

export async function getBossReview(request: ReviewRequest) {
  try {
    const prompt = `
    Review Request for ${request.docType.toUpperCase()} document.
    - Report Purpose: ${request.purpose}
    - Audience: ${request.audience}
    - Specific Focus Area: ${request.focusArea}
    
    Content Summary/Context:
    ${request.contentSummary}
    
    Please provide your expert review and guidance based on BOSS's policies.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("BOSS is currently unavailable. Please try again later.");
  }
}
