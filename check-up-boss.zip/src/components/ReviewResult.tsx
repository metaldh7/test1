import React from 'react';
import { motion } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { ArrowLeft, Lightbulb, CheckCircle2, RefreshCw } from 'lucide-react';

interface ReviewResultProps {
  result: string;
  onReset: () => void;
}

export default function ReviewResult({ result, onReset }: ReviewResultProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-3xl mx-auto"
    >
      <div className="frosted-glass rounded-[2.5rem] shadow-sm overflow-hidden flex flex-col">
        <div className="px-8 py-6 border-b border-white/50 flex justify-between items-center bg-white/30">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-glass-accent/10 rounded-xl">
              <Lightbulb className="w-6 h-6 text-glass-accent" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">BOSS의 논리 점검 가이드라인</h2>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5">Ref: 24년 상반기 리뷰 결과 반영</p>
            </div>
          </div>
          <button
            onClick={onReset}
            className="p-2 hover:bg-glass-accent/10 rounded-full transition-colors text-slate-400 hover:text-glass-accent"
            title="다시 작성하기"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>

        <div className="p-10">
          <div className="markdown-body prose max-w-none">
            <ReactMarkdown>{result}</ReactMarkdown>
          </div>
          
          <div className="mt-10 pt-10 border-t border-white/50 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">스스로 점검해보기 (Self-Check)</h4>
              <div className="space-y-3">
                <CheckItem text="데이터가 보고의 핵심 가설을 직접적으로 증명하는가?" />
                <CheckItem text="논리적 비약이 있는 페이지나 슬라이드는 없는가?" />
                <CheckItem text="그래프의 추세가 텍스트 설명과 일치하는가?" />
              </div>
            </div>

            <div className="bg-orange-50/30 p-6 rounded-3xl border border-orange-100/50">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-glass-accent shadow-sm">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-800 text-sm">최종 점검 포인트</h3>
              </div>
              <p className="text-xs text-slate-500 italic leading-relaxed">
                "결국 본질은 현상 너머의 진짜 원인입니다. 우리가 해야 할 일이 명확히 드러나 있는지 다시 한번 읽어보세요."
              </p>
            </div>
          </div>
        </div>

        {/* Status Bar */}
        <div className="px-8 py-4 bg-slate-900 flex flex-wrap gap-4 justify-between items-center">
          <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
            검토 준비도: <span className="text-white">85%</span>
          </div>
          <div className="flex-1 max-w-[200px] h-1.5 bg-slate-700 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '85%' }}
              transition={{ duration: 1, delay: 0.5 }}
              className="h-full bg-glass-accent"
            />
          </div>
          <span className="text-slate-500 text-[10px] font-medium tracking-tight italic">
            BOSS와의 리뷰 전, 스스로의 논리를 충분히 다듬으셨나요?
          </span>
        </div>
      </div>

      <button
        onClick={onReset}
        className="mt-8 mx-auto flex items-center gap-2 text-slate-500 font-bold text-sm uppercase tracking-widest hover:text-glass-accent transition-all group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        다른 문서 검토하기
      </button>
    </motion.div>
  );
}

function CheckItem({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-3 bg-white/40 p-3 rounded-2xl border border-white/50 group hover:bg-white/60 transition-colors cursor-pointer">
      <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-glass-accent focus:ring-glass-accent" />
      <span className="text-[11px] text-slate-600 font-medium">{text}</span>
    </div>
  );
}
