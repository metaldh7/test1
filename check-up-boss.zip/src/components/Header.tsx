import React from 'react';
import { motion } from 'motion/react';
import { ChefHat, ClipboardCheck, Sparkles } from 'lucide-react';

export default function Header() {
  return (
    <nav className="h-20 flex items-center justify-between px-8 bg-white/40 backdrop-blur-md border-b border-white/50 sticky top-0 z-50 mb-12">
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex items-center gap-4"
      >
        <div className="w-11 h-11 bg-glass-accent rounded-2xl flex items-center justify-center shadow-lg shadow-orange-200 transition-transform hover:scale-105 active:scale-95 cursor-pointer">
          <ClipboardCheck className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">
            Check up <span className="text-glass-accent">BOSS</span>
          </h1>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Logic Review Guide</p>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="hidden md:flex items-center gap-8"
      >
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
          <span className="w-2.5 h-2.5 bg-glass-secondary rounded-full animate-pulse"></span>
          BOSS Policy: Active
        </div>
        <div className="w-10 h-10 bg-slate-200 rounded-full border-2 border-white shadow-sm overflow-hidden bg-[url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces&q=80')] bg-cover" />
      </motion.div>
    </nav>
  );
}
