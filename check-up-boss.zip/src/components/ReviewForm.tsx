import React, { useState } from 'react';
import { motion } from 'motion/react';
import { FileSpreadsheet, BarChart3, Presentation, Send, AlertCircle, Zap } from 'lucide-react';
import { cn } from '../lib/utils';
import { ReviewRequest } from '../services/geminiService';

interface ReviewFormProps {
  onSubmit: (request: ReviewRequest) => void;
  isLoading: boolean;
}

export default function ReviewForm({ onSubmit, isLoading }: ReviewFormProps) {
  const [request, setRequest] = useState<ReviewRequest>({
    purpose: '',
    audience: '',
    focusArea: '',
    docType: 'pptx',
    contentSummary: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!request.purpose || !request.contentSummary) return;
    onSubmit(request);
  };

  const docTypes = [
    { id: 'excel', label: 'Excel / Data', icon: BarChart3 },
    { id: 'graph', label: '2D/3D Graph', icon:BarChart3 },
    { id: 'pptx', label: 'PPTX / Logic', icon: Presentation },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto frosted-glass rounded-[2.5rem] p-10 shadow-sm"
    >
      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <h2 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <Send className="w-5 h-5 text-glass-accent" />
            리뷰 컨텍스트 설정
          </h2>
          <div className="grid grid-cols-3 gap-4">
            {docTypes.map((type) => (
              <button
                key={type.id}
                type="button"
                onClick={() => setRequest({ ...request, docType: type.id as any })}
                className={cn(
                  "flex flex-col items-center justify-center p-5 rounded-3xl border-2 transition-all duration-300",
                  request.docType === type.id
                    ? "border-glass-accent bg-white text-glass-accent shadow-lg shadow-orange-100"
                    : "border-transparent bg-white/40 text-slate-400 hover:bg-white/60"
                )}
              >
                <type.icon className="w-6 h-6 mb-2" />
                <span className="text-[10px] font-bold uppercase tracking-widest">{type.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">
                보고의 목적
              </label>
              <input
                type="text"
                required
                placeholder="예: 신규 기술 타당성 검토"
                value={request.purpose}
                onChange={(e) => setRequest({ ...request, purpose: e.target.value })}
                className="w-full bg-white/80 border-0 rounded-2xl px-4 py-4 text-sm ring-1 ring-slate-100 focus:ring-2 focus:ring-glass-accent outline-none transition-all shadow-sm"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">
                보고 대상
              </label>
              <input
                type="text"
                required
                placeholder="예: 기술연구소 상무님 외 2인"
                value={request.audience}
                onChange={(e) => setRequest({ ...request, audience: e.target.value })}
                className="w-full bg-white/80 border-0 rounded-2xl px-4 py-4 text-sm ring-1 ring-slate-100 focus:ring-2 focus:ring-glass-accent outline-none transition-all shadow-sm"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">
              사전 검토 집중 영역
            </label>
            <input
              type="text"
              placeholder="예: 데이터 간의 인과관계 설명이 논리적인지 확인"
              value={request.focusArea}
              onChange={(e) => setRequest({ ...request, focusArea: e.target.value })}
              className="w-full bg-white/80 border-0 rounded-2xl px-4 py-4 text-sm ring-1 ring-slate-100 focus:ring-2 focus:ring-glass-accent outline-none transition-all shadow-sm"
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 block">
              핵심 논리 구조 및 내용 요약
            </label>
            <textarea
              required
              rows={5}
              placeholder="자료의 핵심 내용이나 논리 흐름을 적어주세요."
              value={request.contentSummary}
              onChange={(e) => setRequest({ ...request, contentSummary: e.target.value })}
              className="w-full bg-white/80 border-0 rounded-2xl px-4 py-4 text-sm ring-1 ring-slate-100 focus:ring-2 focus:ring-glass-accent outline-none transition-all shadow-sm resize-none"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-glass-accent text-white py-5 rounded-[2rem] font-bold text-lg flex items-center justify-center gap-3 hover:bg-orange-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-orange-100 active:scale-[0.98]"
        >
          {isLoading ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full"
              />
              BOSS 검토 중...
            </>
          ) : (
            <>
              <Zap className="w-6 h-6" />
              검토 가이드 생성하기
            </>
          )}
        </button>

        <div className="flex items-start gap-4 p-5 bg-orange-50/50 rounded-3xl border border-orange-100">
          <AlertCircle className="w-5 h-5 text-glass-accent mt-0.5 shrink-0" />
          <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
            자료 유출에 민감한 정보는 일반화하거나 가명 처리하여 입력해 주세요. 
            BOSS는 귀하가 입력한 논리 구조를 바탕으로 최적의 가이던스를 제안합니다.
          </p>
        </div>
      </form>
    </motion.div>
  );
}
