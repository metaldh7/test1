docs = [
"""
Heat Dissipation Failure:
Cooling system problem으로 발생할 수 있다.
온도가 비정상적으로 상승할 경우 발생 가능하다.
""",

"""
Tool Wear Failure:
Tool wear 값이 높을 때 발생한다.
예방 정비로 tool 교체 필요.
""",

"""
Overstrain Failure:
Torque가 비정상적으로 높은 경우 발생한다.
기계 과부하 상황일 가능성이 높다.
"""
]


ml_docs = [

"""
RandomForest 성능 개선 방법
- n_estimators 증가
- max_depth tuning
- class imbalance 시 class_weight 사용
""",

"""
Imbalanced dataset 해결 방법
- SMOTE
- class_weight
- threshold tuning
""",

"""
Feature importance가 높은 변수는
interaction feature를 만들면 성능이 개선될 수 있다.
"""
]