import os

gemini_api_key = os.environ.get("GEMINI_API_KEY")  ## gemini api key 발급받아서 넣기
