"""
Word 템플릿에서 키워드를 찾아 다른 내용으로 교체하는 유틸리티
- 본문 단락(paragraphs)
- 표(tables) 안의 셀
- 헤더 / 푸터
에서 키워드를 찾아 교체합니다.

지원 기능
1) 문자열 치환
2) 이미지 치환
   - {"type": "image", "path": "...", "width": 5.5}
   - {"type": "image", "stream": BytesIO(...), "width": 5.5}

주의
- 이미지 치환은 플레이스홀더가 문단 전체와 정확히 일치할 때 가장 안정적으로 동작합니다.
  예) 문단 내용이 "{{용량그래프}}" 한 줄만 있는 경우
"""

from docx import Document
from docx.oxml.ns import qn
from docx.shared import Inches
import copy


def _is_image_replacement(value) -> bool:
    return isinstance(value, dict) and value.get("type") == "image"


def _clear_paragraph(paragraph) -> None:
    """문단 내부의 모든 run 제거"""
    for run in list(paragraph.runs):
        paragraph._p.remove(run._r)


def _get_first_run_rpr(paragraph):
    """첫 번째 run의 서식(rPr) 복사"""
    if paragraph.runs:
        rpr = paragraph.runs[0]._r.find(qn("w:rPr"))
        if rpr is not None:
            return copy.deepcopy(rpr)
    return None


def _add_text_run(paragraph, text: str, first_rpr=None) -> None:
    """문단에 텍스트 run 추가"""
    from docx.oxml import OxmlElement

    new_r = OxmlElement("w:r")
    if first_rpr is not None:
        new_r.append(copy.deepcopy(first_rpr))

    new_t = OxmlElement("w:t")
    new_t.text = text

    if text != text.strip():
        new_t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")

    new_r.append(new_t)
    paragraph._p.append(new_r)


def _insert_image_into_paragraph(paragraph, image_info: dict) -> None:
    """
    문단에 이미지 삽입

    image_info 예시
    ----------------
    {
        "type": "image",
        "path": "graph.png",
        "width": 5.5
    }

    또는

    {
        "type": "image",
        "stream": BytesIO(...),
        "width": 5.5
    }
    """
    run = paragraph.add_run()

    width = image_info.get("width", 5.0)
    height = image_info.get("height", None)

    if "path" in image_info:
        if height is not None:
            run.add_picture(image_info["path"], width=Inches(width), height=Inches(height))
        else:
            run.add_picture(image_info["path"], width=Inches(width))

    elif "stream" in image_info:
        stream = image_info["stream"]
        if hasattr(stream, "seek"):
            stream.seek(0)

        if height is not None:
            run.add_picture(stream, width=Inches(width), height=Inches(height))
        else:
            run.add_picture(stream, width=Inches(width))

    else:
        raise ValueError("이미지 replacement에는 'path' 또는 'stream'이 필요합니다.")


def _replace_in_paragraph(paragraph, replacements: dict) -> bool:
    """
    문단 내 키워드 교체
    - 문자열 치환 지원
    - 이미지 치환 지원
    """
    full_text = "".join(run.text for run in paragraph.runs)
    stripped_text = full_text.strip()

    if not full_text and not paragraph.runs:
        return False

    first_rpr = _get_first_run_rpr(paragraph)

    # 1) 이미지 치환
    # 문단 전체가 플레이스홀더와 일치할 때만 처리
    for keyword, new_value in replacements.items():
        if _is_image_replacement(new_value) and stripped_text == keyword:
            _clear_paragraph(paragraph)
            _insert_image_into_paragraph(paragraph, new_value)
            return True

    # 2) 일반 문자열 치환
    changed = False
    replaced_text = full_text

    for keyword, new_value in replacements.items():
        if _is_image_replacement(new_value):
            continue

        if keyword in replaced_text:
            replaced_text = replaced_text.replace(keyword, str(new_value))
            changed = True

    if not changed:
        return False

    _clear_paragraph(paragraph)
    _add_text_run(paragraph, replaced_text, first_rpr=first_rpr)
    return True


def _iter_all_paragraphs_from_table(table):
    """중첩 표 포함, table 내부 모든 paragraph 순회"""
    for row in table.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                yield para
            for inner_table in cell.tables:
                yield from _iter_all_paragraphs_from_table(inner_table)


def replace_keywords_in_docx(
    input_path: str,
    output_path: str,
    replacements: dict,
) -> int:
    """
    Word 파일을 열어 replacements 에 정의된 키워드를 교체한 뒤 저장

    Parameters
    ----------
    input_path  : 원본 .docx 파일 경로
    output_path : 저장할 .docx 파일 경로
    replacements: {keyword: new_value, ...}

    문자열 치환 예시
    ----------------
    {
        "{{작성자}}": "홍길동"
    }

    이미지 치환 예시
    ----------------
    {
        "{{용량그래프}}": {
            "type": "image",
            "path": "Result/capacity_graph.png",
            "width": 5.5
        }
    }

    Returns
    -------
    교체가 발생한 총 단락 수
    """
    doc = Document(input_path)
    total_replaced = 0

    # 1) 본문 단락
    for para in doc.paragraphs:
        if _replace_in_paragraph(para, replacements):
            total_replaced += 1

    # 2) 표 안 셀
    for table in doc.tables:
        for para in _iter_all_paragraphs_from_table(table):
            if _replace_in_paragraph(para, replacements):
                total_replaced += 1

    # 3) 헤더 / 푸터
    for section in doc.sections:
        for header_footer in (
            section.header,
            section.footer,
            section.even_page_header,
            section.even_page_footer,
            section.first_page_header,
            section.first_page_footer,
        ):
            if header_footer is None:
                continue

            for para in header_footer.paragraphs:
                if _replace_in_paragraph(para, replacements):
                    total_replaced += 1

            for table in header_footer.tables:
                for para in _iter_all_paragraphs_from_table(table):
                    if _replace_in_paragraph(para, replacements):
                        total_replaced += 1

    doc.save(output_path)
    print(f"[완료] '{output_path}' 저장 — 총 {total_replaced}개 단락 교체됨")
    return total_replaced