############################################################
# EDA 결과를 통합하여 텍스트 분석 리포트 생성
############################################################

import pandas as pd
import numpy as np

# 데이터 로드
data = pd.read_csv("./Data/Tabular/AI4I.csv")

############################################################
# 주요 센서 컬럼 정의
############################################################

sensor_columns = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]"
]

############################################################
# 1. 데이터 기본 정보
############################################################

dataset_size = data.shape

num_rows = dataset_size[0]
num_columns = dataset_size[1]

############################################################
# 2. 결측치 확인
############################################################

missing_values = data.isnull().sum()

############################################################
# 3. Failure 분포
############################################################

failure_distribution = data["Failure Type"].value_counts()

############################################################
# 4. Product Type 분포
############################################################

product_distribution = data["Type"].value_counts()

############################################################
# 5. 센서 통계
############################################################

sensor_stats = data[sensor_columns].describe()

############################################################
# 6. Failure Type별 평균 센서값
############################################################

failure_sensor_mean = data.groupby("Failure Type")[sensor_columns].mean()

############################################################
# 7. 상관관계 분석
############################################################

corr_matrix = data[sensor_columns].corr()

############################################################
# 8. 주요 상관관계 찾기
############################################################

corr_pairs = corr_matrix.unstack()

corr_pairs = corr_pairs.sort_values(ascending=False)

############################################################
# 9. 센서 평균값
############################################################

sensor_mean = data[sensor_columns].mean()

############################################################
# 10. 센서 최대값
############################################################

sensor_max = data[sensor_columns].max()

############################################################
# 11. 센서 최소값
############################################################

sensor_min = data[sensor_columns].min()

############################################################
# 텍스트 리포트 생성
############################################################

report_text = f"""

====================================================
AI4I Predictive Maintenance Dataset - EDA Summary
====================================================

[1] Dataset Overview

Number of rows : {num_rows}
Number of columns : {num_columns}


[2] Missing Values

{missing_values}


[3] Failure Distribution

{failure_distribution}


[4] Product Type Distribution

{product_distribution}


[5] Sensor Statistics

{sensor_stats}


[6] Sensor Mean Values

{sensor_mean}


[7] Sensor Max Values

{sensor_max}


[8] Sensor Min Values

{sensor_min}


[9] Failure Type별 평균 센서값

{failure_sensor_mean}


[10] Sensor Correlation Matrix

{corr_matrix}

"""

############################################################
# 텍스트 출력
############################################################

print(report_text)
with open('Quick_EDA_Report.txt', 'w', encoding='utf-8') as file:
    file.write(report_text)