/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  Trophy, 
  RefreshCcw, 
  Info, 
  ShieldCheck, 
  BookOpen, 
  Lightbulb,
  Building2
} from 'lucide-react';

interface Question {
  id: number;
  category: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    category: '회고 및 가치',
    question: 'AIS Corp의 핵심 가치 중 "신뢰"를 가장 잘 설명하는 행동은 무엇인가요?',
    options: [
      '동료의 실수를 즉각 상부에 보고한다.',
      '업무 진행 상황을 투명하게 공유하고 약속된 일정을 준수한다.',
      '모든 회의 내용을 녹음하여 증거를 남긴다.',
      '결재 라인을 거치지 않고 독단적으로 업무를 처리한다.',
      '경쟁사보다 낮은 가격으로 서비스를 제공한다.'
    ],
    correctIndex: 1,
    explanation: '신뢰는 투명한 고유와 책임감 있는 일정 준수에서 시작됩니다.'
  },
  {
    id: 2,
    category: '안전 수칙',
    question: '사무실 내 화재 발생 시 가장 먼저 취해야 할 행동은?',
    options: [
      '중요 서류를 챙기기 위해 책상으로 돌아간다.',
      '엘리베이터를 이용하여 빠르게 1층으로 대피한다.',
      '주변 동료들에게 화재 사실을 알리고 비상계단을 이용해 대피한다.',
      'SNS에 상황을 공유하기 위해 사진을 찍는다.',
      '물에 젖은 수건을 찾으러 탕비실로 달려간다.'
    ],
    correctIndex: 2,
    explanation: '인명 구조가 최우선이며, 화재 시 엘리베이터 사용은 절대 금지입니다.'
  },
  {
    id: 3,
    category: '제품 지식',
    question: 'AIS Corp의 주력 서비스인 "SmartSync AI"의 핵심 기능은 무엇인가요?',
    options: [
      '무인 점포 운영 대행',
      '문서 자동 번역 서비스',
      '팀 프로젝트 일정 및 리소스 최적화',
      '고화질 영상 스트리밍',
      '오프라인 매장 재고 관리'
    ],
    correctIndex: 2,
    explanation: 'SmartSync AI는 팀의 생산성을 높이기 위한 자동화 도구입니다.'
  },
  {
    id: 4,
    category: '근무 규정',
    question: '유연 근무제에 따른 "코어 타임(Core Time)" 필수 협업 시간은 언제인가요?',
    options: [
      '오전 9시 ~ 오후 6시',
      '오후 1시 ~ 오후 4시',
      '오전 10시 ~ 오후 3시',
      '제한 없음, 상시 자유 근무',
      '매일 오전 8시 ~ 오전 10시'
    ],
    correctIndex: 2,
    explanation: 'AIS Corp의 효율적인 협업을 위한 코어 타임은 10시부터 15시까지입니다.'
  },
  {
    id: 5,
    category: '정보 보안',
    question: '모르는 발신인으로부터 첨부파일이 포함된 이메일을 받았을 때 대응 방법은?',
    options: [
      '내용이 궁금하므로 파일을 즉시 열어본다.',
      '지인에게 이메일을 전달하여 확인을 부탁한다.',
      '삭제 후 무시한다.',
      '보안팀에 즉시 보고하고 해당 이메일을 열지 않는다.',
      '발신인에게 답장을 보내 누구인지 묻는다.'
    ],
    correctIndex: 3,
    explanation: '출처가 불분명한 첨부파일은 보안 사고의 주범이므로 보안팀 신고가 우선입니다.'
  },
  {
    id: 6,
    category: '복리 후생',
    question: 'AIS Corp 직원들에게 제공되는 "자기계발비"를 사용할 수 있는 범위가 아닌 것은?',
    options: [
      '직무 관련 온라인 강의 결제',
      '어학 학원 수강료',
      '전공 및 업무 관련 도서 구매',
      '개인 취미용 게임 하드웨어 구매',
      '업무 관련 자격증 응시료'
    ],
    correctIndex: 3,
    explanation: '자기계발비는 개인의 역량 강화와 관계된 항목에 지원됩니다.'
  },
  {
    id: 7,
    category: '제품 지식',
    question: 'SmartSync AI의 유료 플랜 중 "Enterprise" 단계에서만 제공되는 혜택은?',
    options: [
      '무제한 프로젝트 생성',
      '다크 모드 지원',
      '전용 계정 관리자 지원 및 커스텀 보안 설정',
      '모바일 앱 접근권한',
      '팀 채팅 기능'
    ],
    correctIndex: 2,
    explanation: '엔터프라이즈 플랜은 맞춤형 관리와 강화된 보안 기능을 포함합니다.'
  },
  {
    id: 8,
    category: '근무 규정',
    question: '연차 휴가는 사용 예정일 며칠 전까지 승인 요청을 완료해야 하나요?',
    options: [
      '휴가 당일 아침',
      '최소 1일 전',
      '최소 3일 전',
      '최소 7일 전',
      '최소 14일 전'
    ],
    correctIndex: 2,
    explanation: '팀 내 업무 공백을 최소화하기 위해 최소 3일 전 승인 요청이 원칙입니다.'
  },
  {
    id: 9,
    category: '안전 수칙',
    question: '심정지 환자 발생 시 자동심장충격기(AED)의 위치는 어디인가요?',
    options: [
      '각 층 안내 데스크 및 1층 로비',
      '대표이사 사무실 내',
      '건물 외부 흡연구역',
      '구내식당 주방 안',
      '옥상 헬기 착륙장'
    ],
    correctIndex: 0,
    explanation: '응급 상황에 대비해 AED는 각 층의 가장 접근하기 쉬운 위치에 비치되어 있습니다.'
  },
  {
    id: 10,
    category: '회사 정보',
    question: '우리 회사의 공식 홈페이지 주소로 옳은 것은?',
    options: [
      'www.ais-corp.com',
      'www.smart-ais.net',
      'www.global-ais.co.kr',
      'www.ais-startup.io',
      'www.ais-main.com'
    ],
    correctIndex: 0,
    explanation: '공식 브랜드 도메인은 ais-corp.com 입니다.'
  }
];

export default function App() {
  const [step, setStep] = useState<'welcome' | 'quiz' | 'result'>('welcome');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(new Array(QUESTIONS.length).fill(null));
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);

  const handleStart = () => {
    setStep('quiz');
    setCurrentIdx(0);
    setAnswers(new Array(QUESTIONS.length).fill(null));
    setShowFeedback(false);
    setScore(0);
  };

  const handleSelectAnswer = (optionIdx: number) => {
    if (showFeedback) return;

    const newAnswers = [...answers];
    newAnswers[currentIdx] = optionIdx;
    setAnswers(newAnswers);
    setShowFeedback(true);

    if (optionIdx === QUESTIONS[currentIdx].correctIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIdx < QUESTIONS.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setShowFeedback(false);
    } else {
      setStep('result');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 font-sans selection:bg-blue-100 p-4 md:p-8 flex items-center justify-center">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-sm border border-neutral-100 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {step === 'welcome' && (
            <motion.div 
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-8 md:p-12 text-center flex flex-col items-center gap-6"
              id="welcome-screen"
            >
              <div className="bg-blue-50 p-4 rounded-2xl">
                <Building2 className="w-12 h-12 text-blue-600" />
              </div>
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tight text-neutral-900">
                  신입사원 온보딩 퀴즈
                </h1>
                <p className="text-neutral-500 text-lg leading-relaxed">
                  환영합니다! AIS Corp의 일원이 된 것을 축하드립니다.<br />
                  간단한 퀴즈를 통해 우리 회사의 문화와 수칙을 알아보세요.
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full mt-4">
                <div className="bg-neutral-50 p-4 rounded-2xl flex flex-col items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium">안전 수칙</span>
                </div>
                <div className="bg-neutral-50 p-4 rounded-2xl flex flex-col items-center gap-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <span className="text-sm font-medium">제품 지식</span>
                </div>
                <div className="bg-neutral-50 p-4 rounded-2xl flex flex-col items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-600" />
                  <span className="text-sm font-medium">회사 문화</span>
                </div>
              </div>

              <button 
                id="btn-start-quiz"
                onClick={handleStart}
                className="mt-8 group w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 shadow-lg shadow-blue-200"
              >
                시작하기
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          )}

          {step === 'quiz' && (
            <motion.div 
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="p-6 md:p-10"
              id="quiz-container"
            >
              {/* Progress */}
              <div className="flex items-center justify-between mb-8">
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider">
                    {QUESTIONS[currentIdx].category}
                  </p>
                  <p className="text-neutral-400 text-sm">
                    문제 {currentIdx + 1} / {QUESTIONS.length}
                  </p>
                </div>
                <div className="w-32 h-2 bg-neutral-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentIdx + 1) / QUESTIONS.length) * 100}%` }}
                    className="h-full bg-blue-500"
                  />
                </div>
              </div>

              {/* Question */}
              <h2 className="text-xl md:text-2xl font-bold mb-8 leading-tight">
                {QUESTIONS[currentIdx].question}
              </h2>

              {/* Options */}
              <div className="space-y-3 mb-8">
                {QUESTIONS[currentIdx].options.map((option, idx) => {
                  const isSelected = answers[currentIdx] === idx;
                  const isCorrect = idx === QUESTIONS[currentIdx].correctIndex;
                  
                  let style = "bg-white border-neutral-200 hover:border-blue-400 hover:bg-blue-50";
                  if (showFeedback) {
                    if (isCorrect) {
                      style = "bg-green-50 border-green-500 text-green-700 shadow-sm";
                    } else if (isSelected) {
                      style = "bg-red-50 border-red-500 text-red-700";
                    } else {
                      style = "bg-white border-neutral-100 opacity-60";
                    }
                  } else if (isSelected) {
                    style = "bg-blue-50 border-blue-500 text-blue-700";
                  }

                  return (
                    <button
                      key={idx}
                      id={`option-${idx}`}
                      disabled={showFeedback}
                      onClick={() => handleSelectAnswer(idx)}
                      className={`w-full p-4 text-left rounded-2xl border transition-all duration-200 flex items-center justify-between group ${style}`}
                    >
                      <span className="font-medium">{option}</span>
                      {showFeedback && isCorrect && <CheckCircle2 className="w-5 h-5 shrink-0" />}
                      {showFeedback && isSelected && !isCorrect && <XCircle className="w-5 h-5 shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Feedback Section */}
              <div className="min-h-[120px]">
                <AnimatePresence>
                  {showFeedback && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-6"
                    >
                      <div className="bg-neutral-50 p-4 rounded-2xl flex gap-3 border border-neutral-100">
                        <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                        <p className="text-sm text-neutral-600 leading-relaxed">
                          {QUESTIONS[currentIdx].explanation}
                        </p>
                      </div>
                      <button
                        id="btn-next"
                        onClick={handleNext}
                        className="w-full bg-neutral-900 text-white font-semibold py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-800 transition-colors active:scale-[0.98]"
                      >
                        {currentIdx === QUESTIONS.length - 1 ? '결과 보기' : '다음 문제'}
                        <ArrowRight className="w-5 h-5" />
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {step === 'result' && (
            <motion.div 
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 md:p-12 text-center"
              id="result-screen"
            >
              <div className="mb-8 flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="bg-amber-50 p-6 rounded-full">
                    <Trophy className="w-16 h-16 text-amber-500" />
                  </div>
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.3 }}
                    className="absolute -top-3 -right-3 bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-full"
                  >
                    축하합니다!
                  </motion.div>
                </div>
                <div className="space-y-1">
                  <h2 className="text-3xl font-extrabold text-neutral-900">
                    퀴즈 완료
                  </h2>
                  <p className="text-neutral-500">훌륭한 시작입니다!</p>
                </div>
              </div>

              <div className="bg-neutral-50 rounded-3xl p-8 mb-8 grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-3xl font-black text-blue-600">{score}</p>
                  <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest">맞은 개수</p>
                </div>
                <div className="space-y-1">
                  <p className="text-3xl font-black text-neutral-900">{Math.round((score / QUESTIONS.length) * 100)}%</p>
                  <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest">최종 점수</p>
                </div>
              </div>

              {/* Review section placeholder */}
              <div className="text-left space-y-4 mb-8">
                <p className="text-sm font-bold text-neutral-400 uppercase tracking-wider ml-1">오답 다시보기</p>
                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                  {QUESTIONS.map((q, i) => {
                    if (answers[i] !== q.correctIndex) {
                      return (
                        <div key={i} className="p-4 bg-white border border-red-100 rounded-2xl flex gap-3">
                          <XCircle className="w-5 h-5 text-red-400 shrink-0" />
                          <div className="space-y-1">
                            <p className="text-sm font-semibold text-neutral-800">{q.question}</p>
                            <p className="text-xs text-neutral-500 italic">정답: {q.options[q.correctIndex]}</p>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })}
                  {score === QUESTIONS.length && (
                    <div className="p-6 bg-blue-50 rounded-2xl text-center border border-blue-100">
                      <p className="text-blue-700 font-medium italic">모든 문제를 맞히셨습니다! AIS Corp의 전문가이시군요! 🚀</p>
                    </div>
                  )}
                </div>
              </div>

              <button 
                id="btn-restart"
                onClick={handleStart}
                className="w-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-semibold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <RefreshCcw className="w-5 h-5" />
                다시 풀어보기
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f8f8f8;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e0e0e0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #d0d0d0;
        }
      `}</style>
    </div>
  );
}
