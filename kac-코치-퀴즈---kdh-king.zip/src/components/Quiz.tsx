import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CheckCircle2, XCircle, ChevronRight, HelpCircle } from "lucide-react";
import { Question } from "../data/quizData";

interface QuizProps {
  questions: Question[];
  onComplete: (score: number, userAnswers: number[]) => void;
}

export default function Quiz({ questions, onComplete }: QuizProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [score, setScore] = useState(0);

  const currentQuestion = questions[currentIdx];

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedIdx(idx);
  };

  const handleConfirm = () => {
    if (selectedIdx === null) return;
    
    const isCorrect = selectedIdx === currentQuestion.answer;
    if (isCorrect) setScore(s => s + 1);
    
    setIsAnswered(true);
    setUserAnswers(prev => [...prev, selectedIdx]);
  };

  const handleNext = () => {
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setSelectedIdx(null);
      setIsAnswered(false);
    } else {
      onComplete(score, [...userAnswers]);
    }
  };

  const progress = ((currentIdx + 1) / questions.length) * 100;

  return (
    <div className="max-w-2xl mx-auto w-full px-4 py-8">
      {/* Progress Header */}
      <div className="mb-8">
        <div className="flex justify-between items-end mb-2">
          <span className="text-sm font-bold text-indigo-600 uppercase tracking-wider">
            Question {currentIdx + 1} of {questions.length}
          </span>
          <span className="text-2xl font-serif font-bold text-slate-800">
            {Math.round(progress)}%
          </span>
        </div>
        <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-indigo-600"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIdx}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200 border border-slate-100"
        >
          <h2 className="text-2xl md:text-3xl font-bold text-slate-800 mb-8 leading-tight">
            {currentQuestion.question}
          </h2>

          <div className="space-y-3">
            {currentQuestion.options.map((option, idx) => {
              let statusClass = "border-slate-200 hover:border-indigo-300 bg-white";
              if (selectedIdx === idx) statusClass = "border-indigo-600 bg-indigo-50 text-indigo-900 ring-2 ring-indigo-600 ring-offset-2";
              
              if (isAnswered) {
                if (idx === currentQuestion.answer) {
                  statusClass = "border-emerald-500 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500 ring-offset-2";
                } else if (selectedIdx === idx && selectedIdx !== currentQuestion.answer) {
                  statusClass = "border-rose-500 bg-rose-50 text-rose-900 ring-2 ring-rose-500 ring-offset-2";
                } else {
                  statusClass = "opacity-50 border-slate-100";
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={isAnswered}
                  className={`w-full text-left p-5 rounded-2xl border-2 transition-all flex items-center justify-between group ${statusClass} cursor-pointer`}
                >
                  <span className="text-lg font-medium">{option}</span>
                  {isAnswered && idx === currentQuestion.answer && (
                    <CheckCircle2 className="w-6 h-6 text-emerald-600 flex-shrink-0 ml-3" />
                  )}
                  {isAnswered && selectedIdx === idx && selectedIdx !== currentQuestion.answer && (
                    <XCircle className="w-6 h-6 text-rose-600 flex-shrink-0 ml-3" />
                  )}
                </button>
              );
            })}
          </div>

          <div className="mt-10 flex justify-end">
            {!isAnswered ? (
              <button
                onClick={handleConfirm}
                disabled={selectedIdx === null}
                className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold disabled:opacity-30 disabled:cursor-not-allowed hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
              >
                정답 확인
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="px-8 py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-colors flex items-center gap-2 group"
              >
                {currentIdx < questions.length - 1 ? "다음 문제" : "결과 보기"}
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            )}
          </div>

          {isAnswered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-8 p-6 rounded-2xl border-l-4 flex gap-4 ${
                selectedIdx === currentQuestion.answer 
                  ? "bg-emerald-50 border-emerald-500 text-emerald-900" 
                  : "bg-rose-50 border-rose-500 text-rose-900"
              }`}
            >
              <div className={`p-2 rounded-full h-fit ${
                selectedIdx === currentQuestion.answer ? "bg-emerald-200" : "bg-rose-200"
              }`}>
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold mb-1">
                  {selectedIdx === currentQuestion.answer ? "참 잘하셨습니다!" : "아쉽네요. 정답은 0번입니다.".replace("0", (currentQuestion.answer + 1).toString())}
                </p>
                <p className="text-sm leading-relaxed opacity-80">
                  {currentQuestion.explanation}
                </p>
              </div>
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
