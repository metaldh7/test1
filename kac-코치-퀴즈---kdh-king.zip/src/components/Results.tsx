import { motion } from "motion/react";
import { CheckCircle, XCircle, RotateCcw, Award } from "lucide-react";
import { Question } from "../data/quizData";

interface ResultsProps {
  questions: Question[];
  score: number;
  userAnswers: number[];
  onRestart: () => void;
}

export default function Results({ questions, score, userAnswers, onRestart }: ResultsProps) {
  const percentage = (score / questions.length) * 100;
  
  let grade = "학습이 더 필요합니다";
  let color = "text-rose-600";
  if (percentage === 100) {
    grade = "당신은 진정한 KDH King!";
    color = "text-indigo-600";
  } else if (percentage >= 80) {
    grade = "훌륭합니다! 거의 완벽해요";
    color = "text-emerald-600";
  } else if (percentage >= 60) {
    grade = "준수합니다! 조금 더 복습해볼까요?";
    color = "text-amber-600";
  }

  return (
    <div className="max-w-3xl mx-auto w-full px-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-10 shadow-2xl shadow-slate-200 border border-slate-100 text-center mb-12"
      >
        <div className="inline-flex items-center justify-center p-6 bg-indigo-50 rounded-full mb-6">
          <Award className="w-16 h-16 text-indigo-600" />
        </div>
        
        <h2 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-2">Quiz Finished!</h2>
        <p className={`text-xl font-bold mb-8 ${color}`}>{grade}</p>
        
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-slate-50 p-6 rounded-2xl">
            <p className="text-sm uppercase tracking-widest text-slate-500 font-bold mb-1">Score</p>
            <p className="text-4xl font-serif font-bold text-slate-800">{score} / {questions.length}</p>
          </div>
          <div className="bg-slate-50 p-6 rounded-2xl">
            <p className="text-sm uppercase tracking-widest text-slate-500 font-bold mb-1">Accuracy</p>
            <p className="text-4xl font-serif font-bold text-slate-800">{Math.round(percentage)}%</p>
          </div>
        </div>

        <button
          onClick={onRestart}
          className="flex items-center gap-2 mx-auto px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100 cursor-pointer"
        >
          <RotateCcw className="w-5 h-5" />
          다시 도전하기
        </button>
      </motion.div>

      <div className="space-y-6">
        <h3 className="text-2xl font-bold text-slate-800 px-4">오답 노트 & 해설</h3>
        {questions.map((q, idx) => {
          const isCorrect = userAnswers[idx] === q.answer;
          if (isCorrect) return null;

          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white rounded-2xl p-6 border border-slate-100 shadow-lg shadow-slate-100/50"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="bg-rose-100 p-2 rounded-lg">
                  <XCircle className="w-6 h-6 text-rose-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-400 font-bold mb-1 uppercase tracking-tight">Question {idx + 1}</p>
                  <h4 className="text-lg font-bold text-slate-800 leading-tight">{q.question}</h4>
                </div>
              </div>

              <div className="space-y-3 pl-12">
                <div className="p-3 bg-rose-50 rounded-xl border border-rose-100 text-rose-900 text-sm">
                  <span className="font-bold mr-2">선택:</span> {q.options[userAnswers[idx]]}
                </div>
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-emerald-900 text-sm">
                  <span className="font-bold mr-2">정답:</span> {q.options[q.answer]}
                </div>
                <div className="mt-4 p-4 bg-slate-50 rounded-xl text-slate-700 text-sm leading-relaxed border border-slate-200">
                  <p className="font-bold mb-1 text-slate-900 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    해설
                  </p>
                  {q.explanation}
                </div>
              </div>
            </motion.div>
          );
        })}
        {score === questions.length && (
          <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-12 text-center">
            <p className="text-lg font-medium text-indigo-900">틀린 문제가 없습니다! 완벽한 실력이시네요. 🎉</p>
          </div>
        )}
      </div>
    </div>
  );
}
