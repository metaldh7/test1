import { motion } from "motion/react";
import { Trophy } from "lucide-react";

interface HomeProps {
  onStart: () => void;
}

export default function Home({ onStart }: HomeProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <div className="mb-6 flex justify-center">
          <div className="p-4 bg-indigo-100 rounded-2xl">
            <Trophy className="w-12 h-12 text-indigo-600" />
          </div>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-serif font-bold italic tracking-tighter text-indigo-900 mb-4">
          KDH King
        </h1>
        
        <p className="text-lg md:text-xl text-slate-600 max-w-md mx-auto mb-12 leading-relaxed">
          신규 KAC 코치를 위한 필수 지식 퀴즈.<br />
          당신의 코칭 역량을 확인해보세요.
        </p>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="px-10 py-4 bg-indigo-600 text-white font-bold rounded-full shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-colors text-lg cursor-pointer"
        >
          퀴즈 시작하기
        </motion.button>
        
        <div className="mt-12 text-sm text-slate-400 font-medium tracking-wide uppercase">
          Korea Coach Association • KAC Certification
        </div>
      </motion.div>
    </div>
  );
}
