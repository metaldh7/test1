/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import Home from "./components/Home";
import Quiz from "./components/Quiz";
import Results from "./components/Results";
import { quizData } from "./data/quizData";

type AppState = "HOME" | "QUIZ" | "RESULTS";

export default function App() {
  const [state, setState] = useState<AppState>("HOME");
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const handleStart = () => {
    setState("QUIZ");
  };

  const handleComplete = (finalScore: number, answers: number[]) => {
    setScore(finalScore);
    setUserAnswers(answers);
    setState("RESULTS");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleRestart = () => {
    setScore(0);
    setUserAnswers([]);
    setState("HOME");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-indigo-100">
      <main className="container mx-auto py-12">
        {state === "HOME" && <Home onStart={handleStart} />}
        {state === "QUIZ" && (
          <Quiz questions={quizData} onComplete={handleComplete} />
        )}
        {state === "RESULTS" && (
          <Results
            questions={quizData}
            score={score}
            userAnswers={userAnswers}
            onRestart={handleRestart}
          />
        )}
      </main>
      
      <footer className="py-8 text-center text-slate-400 text-sm border-t border-slate-100">
        © 2026 KAC Coach Certification Help Tool - KDH King
      </footer>
    </div>
  );
}

